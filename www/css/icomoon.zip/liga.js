/* A polyfill for browsers that don't support ligatures. */
/* The script tag referring to this file must be placed before the ending body tag. */

/* To provide support for elements dynamically added, this script adds
   method 'icomoonLiga' to the window object. You can pass element references to this method.
*/
(function () {
    'use strict';
    function supportsProperty(p) {
        var prefixes = ['Webkit', 'Moz', 'O', 'ms'],
            i,
            div = document.createElement('div'),
            ret = p in div.style;
        if (!ret) {
            p = p.charAt(0).toUpperCase() + p.substr(1);
            for (i = 0; i < prefixes.length; i += 1) {
                ret = prefixes[i] + p in div.style;
                if (ret) {
                    break;
                }
            }
        }
        return ret;
    }
    var icons;
    if (!supportsProperty('fontFeatureSettings')) {
        icons = {
            'camera_alt': '&#xe412;',
            'local_see': '&#xe412;',
            'photo_camera': '&#xe412;',
            'cloud_done': '&#xe2bf;',
            'desktop_windows': '&#xe30c;',
            'group': '&#xe7fb;',
            'people': '&#xe7fb;',
            'linked_camera': '&#xe438;',
            'local_library': '&#xe54b;',
            'new_releases': '&#xe031;',
            'offline_pin': '&#xe90a;',
            'open_in_browser': '&#xe89d;',
            'pan_tool': '&#xe925;',
            'people_outline': '&#xe7fc;',
            'personal_video': '&#xe63b;',
            'phonelink_ring': '&#xe0dd;',
            'phonelink_setup': '&#xe0de;',
            'public': '&#xe80b;',
            'queue_play_next': '&#xe066;',
            'record_voice_over': '&#xe91f;',
            'supervisor_account': '&#xe8d3;',
          '0': 0
        };
        delete icons['0'];
        window.icomoonLiga = function (els) {
            var classes,
                el,
                i,
                innerHTML,
                key;
            els = els || document.getElementsByTagName('*');
            if (!els.length) {
                els = [els];
            }
            for (i = 0; ; i += 1) {
                el = els[i];
                if (!el) {
                    break;
                }
                classes = el.className;
                if (/icomoon-liga/.test(classes)) {
                    innerHTML = el.innerHTML;
                    if (innerHTML && innerHTML.length > 1) {
                        for (key in icons) {
                            if (icons.hasOwnProperty(key)) {
                                innerHTML = innerHTML.replace(new RegExp(key, 'g'), icons[key]);
                            }
                        }
                        el.innerHTML = innerHTML;
                    }
                }
            }
        };
        window.icomoonLiga();
    }
}());
